from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

# Set the start date to the current date
current_date = datetime.today()

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': current_date,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'data_pipeline',
    default_args=default_args,
    description='A DAG to run data pipeline scripts sequentially',
    schedule_interval='30 2,9 * * *',  # Runs at 2:30 AM and 9:30 AM every day
    catchup=False #prevents running past dates
)

task1 = BashOperator(
    task_id='generate_data',
    bash_command='source /home/bsk/myenv/bin/activate && python /home/bsk/PycharmProjects/DE/scripts/generate_data_with_config.py',
    dag=dag,
)

task2 = BashOperator(
    task_id='bronze_layer',
    bash_command='source /home/bsk/myenv/bin/activate && python /home/bsk/PycharmProjects/DE/scripts/bronze_layer.py',
    dag=dag,
)

task3 = BashOperator(
    task_id='silver_layer',
    bash_command='source /home/bsk/myenv/bin/activate && python /home/bsk/PycharmProjects/DE/scripts/silver_layer.py',
    dag=dag,
)

task4 = BashOperator(
    task_id='gold_layer',
    bash_command='source /home/bsk/myenv/bin/activate && python /home/bsk/PycharmProjects/DE/scripts/gold_layer.py',
    dag=dag,
)

task1 >> task2 >> task3 >> task4

