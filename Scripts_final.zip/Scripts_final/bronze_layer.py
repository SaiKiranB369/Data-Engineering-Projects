import os
import json
import datetime
import logging
import shutil
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, current_timestamp
import configparser
from datetime import datetime

# Initialize Spark Session
spark = SparkSession.builder.appName("BronzeLayerProcessing").getOrCreate()

'''
# Load configuration
def load_config(config_file="/home/bsk/PycharmProjects/DE/config.json"):
    default_config = {
        "paths": {
            "output_folder": "output",
            "tracker_file": "id_tracker.json"
        },
        "data_settings": {
            "num_rows_per_table": 500
        }
    }

    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            user_config = json.load(f)
            for key, value in user_config.items():
                if key in default_config and isinstance(value, dict):
                    default_config[key].update(value)
                else:
                    default_config[key] = value

    return default_config


config = load_config()
output_folder = config["paths"]["output_folder"]
bronze_folder = "/home/bsk/PycharmProjects/DE/medallion/bronze"

# Logging Setup
log_file = "/home/bsk/PycharmProjects/DE/logs/pipeline_log.txt"
'''


def read_config():
    """Load config.ini from the project root directory."""
    script_dir = os.path.dirname(os.path.abspath(__file__))  # Get script directory
    config_path = os.path.join(script_dir, "config2.ini")
    # project_root = os.path.abspath(os.path.join(script_dir, ".."))  # Move up one level
    # config_path = os.path.join(project_root, "config2.ini")  # Full path to config.ini

    if not os.path.exists(config_path):  # Check if file exists
        raise FileNotFoundError(f"Error: config.ini not found at {config_path}")

    config_obj = configparser.ConfigParser()
    config_obj.read(config_path)  # Read config file

    if not config_obj.sections():  # Ensure config isn't empty
        raise ValueError("Error: config.ini is empty or misformatted!")

    return config_obj

# Load config.ini
config = read_config()

# Retrieve paths
bronze_input = config['PATHS']['input_path_bronze_processing_layer']
bronze_output = config['PATHS']['output_path_bronze_processing_layer']


# Print results
print(f"Bronze Input: {bronze_input}")
print(f"Bronze Output: {bronze_output}")


log_file = config['PATHS']['logs_folder']
logging.basicConfig(filename=log_file, level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Expected Schema for Each File
expected_schemas = {
    "customers": ["customer_id", "full_name", "email", "address", "city", "state"],
    "products": ["product_id", "product_name", "category", "price"],
    "orders": ["order_id", "order_date", "customer_id", "total_amount", "order_status"],
    "order_items": ["order_item_id", "order_id", "product_id", "quantity", "unit_price"]
}


def get_latest_folder(path):
    """Finds the most recent timestamped raw data folder."""
    if not os.path.exists(path):
        return None
    folders = [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d)) and d.startswith("raw_files_")]
    latest_folder = sorted(folders, reverse=True)[0] if folders else None
    return os.path.join(path, latest_folder) if latest_folder else None


def validate_schema(df, expected_columns):
    """Validates if DataFrame has the expected schema."""
    return set(df.columns) == set(expected_columns)

def process_bronze_layer(raw_path, bronze_output):
    """Processes raw CSVs into Bronze layer with basic validation."""
    latest_raw_folder = get_latest_folder(raw_path)
    if not latest_raw_folder:
        logging.error("No raw data found!")
        return

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    bronze_timestamped_folder = os.path.join(bronze_output, f"bronze_files_{timestamp}")
    os.makedirs(bronze_timestamped_folder, exist_ok=True)

    files = {
        "customers": ["customer_id", "full_name", "email", "address", "city", "state"],
        "products": ["product_id", "product_name", "category", "price"],
        "orders": ["order_id", "order_date", "customer_id", "total_amount", "order_status"],
        "order_items": ["order_item_id", "order_id", "product_id", "quantity", "unit_price"]
    }

    source_system = "DataIngestionSystem"
    ingest_timestamp = datetime.now().isoformat()
    raw_timestamp = '_'.join(os.path.basename(latest_raw_folder).split('_')[-2:])

    for file, columns in files.items():
        raw_file_path = os.path.join(latest_raw_folder, f"raw_{file}_{raw_timestamp}.csv")
        if os.path.exists(raw_file_path):
            df = spark.read.csv(raw_file_path, header=True, inferSchema=True)
            if validate_schema(df, columns):
                df = df.withColumn("ingest_timestamp", lit(ingest_timestamp)) \
                       .withColumn("source_system", lit(source_system))

                # Coalesce and write to a single file
                temp_path = os.path.join(bronze_timestamped_folder, f"bronze_{file}_temp_{timestamp}")
                final_path = os.path.join(bronze_timestamped_folder, f"bronze_{file}_{timestamp}.csv")
                df.coalesce(1).write.csv(temp_path, header=True, mode="overwrite")

                # Move the part file to the final destination
                for filename in os.listdir(temp_path):
                    if filename.startswith("part-"):
                        shutil.move(os.path.join(temp_path, filename), final_path)
                        break

                # Clean up the temp directory
                shutil.rmtree(temp_path)

                logging.info(f"Saved bronze file: {final_path}")
            else:
                logging.error(f"Schema mismatch in {file}")
        else:
            logging.warning(f"Raw file not found: {raw_file_path}")

    logging.info(f"Bronze files saved in {bronze_timestamped_folder}")


if __name__ == "__main__":
    raw_path = bronze_input
    process_bronze_layer(raw_path, bronze_output)
