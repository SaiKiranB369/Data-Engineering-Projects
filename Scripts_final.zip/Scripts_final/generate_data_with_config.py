import json
import random
import datetime
import os
import logging
from pyspark.sql import SparkSession, Row
import shutil
import configparser

# Load configuration from config.ini
config_ini = configparser.ConfigParser()

def read_config2():
    """Load config.ini from the project root directory."""
    script_dir = os.path.dirname(os.path.abspath(__file__))  # Get script directory
    config_path = os.path.join(script_dir, "config2.ini")
    #project_root = os.path.abspath(os.path.join(script_dir, ".."))  # Move up one level
    #config_path = os.path.join(project_root, "config2.ini")  # Full path to config.ini

    if not os.path.exists(config_path):  # Check if file exists
        raise FileNotFoundError(f"Error: config.ini not found at {config_path}")

    config_obj = configparser.ConfigParser()
    config_obj.read(config_path)  # Read config file

    if not config_obj.sections():  # Ensure config isn't empty
        raise ValueError("Error: config.ini is empty or misformatted!")

    return config_obj

config_ini.read("config.ini")

# Get log file path from config.ini
log_file = config_ini.get("LOGGING", "log_file", fallback="logs/pipeline_log.txt")

# Define default config file path (without hardcoding it here)
def load_config(config_file="config.json"):
    """Loads configuration from a JSON file. If missing, returns default settings."""
    default_config = {
        "paths": {
            "output_folder": "output",
            "tracker_file": "id_tracker.json"
        },
        "data_settings": {
            "num_rows_per_table": 500
        }
    }

    # Get the absolute path of config.json based on the current working directory
    config_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), config_file)

    if os.path.exists(config_file_path):
        try:
            with open(config_file_path, 'r') as f:
                user_config = json.load(f)
            for key, value in user_config.items():
                if key in default_config and isinstance(value, dict):
                    default_config[key].update(value)
                else:
                    default_config[key] = value
        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Could not read '{config_file_path}', using defaults. Error: {e}")

    return default_config

# Load configuration
config = load_config()
output_folder = config["paths"]["output_folder"]
tracker_file = config["paths"]["tracker_file"]

# Ensure Output and Log Directories Exist and Files are Created if Not Present
def ensure_directory_and_file(directory, file_path=None):
    """Ensures the directory exists, and the file is created if it doesn't exist."""
    os.makedirs(directory, exist_ok=True)
    if file_path and not os.path.exists(file_path):
        with open(file_path, 'w') as f:
            f.write("{}")  # Creating an empty JSON file if not present

# Ensure the directories and files for logs, output, and tracker exist
ensure_directory_and_file(os.path.dirname(log_file), log_file)  # Logs
ensure_directory_and_file(output_folder)  # Output folder
ensure_directory_and_file(os.path.dirname(tracker_file), tracker_file)  # Tracker file

logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logging.info("🚀 Data Generation Process Started")

def load_id_tracker(tracker_path):
    """Loads ID tracker JSON. Returns default IDs if file is missing or corrupt."""
    if os.path.exists(tracker_path):
        try:
            with open(tracker_path, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            logging.error(f"⚠ Warning: Could not read ID tracker. Error: {e}")

    return {"customers": 10000, "products": 10000, "orders": 10000, "order_items": 10000}

def save_id_tracker(tracker, tracker_path):
    """Saves the updated ID tracker JSON."""
    with open(tracker_path, 'w') as f:
        json.dump(tracker, f, indent=2)

def random_date(start_date, end_date):
    """Generate a random date between start_date and end_date."""
    start_ts = int(start_date.timestamp())
    end_ts = int(end_date.timestamp())
    rand_ts = random.randint(start_ts, end_ts)
    return datetime.date.fromtimestamp(rand_ts)

def generate_customers(num_rows, start_id):
    """Generates customers dataset."""
    states = ["NY", "CA", "TX", "IL", "FL", "WA", "MA", "OH", "GA", "NC"]
    cities = ["New York", "Los Angeles", "Houston", "Chicago", "Miami", "Seattle", "Boston", "Cleveland", "Atlanta", "Charlotte"]

    return [Row(
        customer_id=i,
        full_name=f"Customer {i}",
        email=f"customer{i}@example.com",
        address=f"{random.randint(1,9999)} Main St",
        city=random.choice(cities),
        state=random.choice(states)
    ) for i in range(start_id, start_id + num_rows)]

def generate_products(num_rows, start_id):
    """Generates products dataset."""
    categories = ["Electronics", "Wearables", "Home Decor", "Kitchen", "Sports"]
    return [Row(
        product_id=i,
        product_name=f"Product {i}",
        category=random.choice(categories),
        price=round(random.uniform(5.0, 1000.0), 2)
    ) for i in range(start_id, start_id + num_rows)]

def generate_orders(num_rows, start_id, max_customer_id, order_date):
    """Generates orders dataset."""
    statuses = ["SHIPPED", "PENDING", "CANCELLED", "DELIVERED"]
    return [Row(
        order_id=i,
        order_date=order_date,
        customer_id=random.randint(1, max_customer_id),
        total_amount=round(random.uniform(0.0, 5000.0), 2),
        order_status=random.choice(statuses)
    ) for i in range(start_id, start_id + num_rows)]

def generate_order_items(num_rows, start_id, max_order_id, max_product_id):
    """Generates order items dataset."""
    return [Row(
        order_item_id=i,
        order_id=random.randint(1, max_order_id),
        product_id=random.randint(1, max_product_id),
        quantity=random.randint(1, 10),
        unit_price=round(random.uniform(5.0, 500.0), 2)
    ) for i in range(start_id, start_id + num_rows)]

def main():
    """Main function to generate data."""
    try:
        # Initialize Spark session
        spark = SparkSession.builder.appName("DataGeneration").getOrCreate()

        tracker = load_id_tracker(tracker_file)
        run_date = datetime.date.today()
        file_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        # ✅ Create a timestamped folder inside the output directory
        timestamped_folder = os.path.join(output_folder, f"raw_files_{file_timestamp}")
        os.makedirs(timestamped_folder, exist_ok=True)  # Ensure the folder is created

        # Generate Data
        num_rows = config["data_settings"]["num_rows_per_table"]

        c_start_id = tracker["customers"] + 1
        customers_data = generate_customers(num_rows, c_start_id)
        tracker["customers"] = c_start_id + len(customers_data) - 1

        p_start_id = tracker["products"] + 1
        products_data = generate_products(num_rows, p_start_id)
        tracker["products"] = p_start_id + len(products_data) - 1

        o_start_id = tracker["orders"] + 1
        orders_data = generate_orders(num_rows, o_start_id, tracker["customers"], run_date)
        tracker["orders"] = o_start_id + len(orders_data) - 1

        oi_start_id = tracker["order_items"] + 1
        order_items_data = generate_order_items(num_rows, oi_start_id, tracker["orders"], tracker["products"])
        tracker["order_items"] = oi_start_id + len(order_items_data) - 1

        save_id_tracker(tracker, tracker_file)

        # Convert lists of Rows to DataFrames
        customers_df = spark.createDataFrame(customers_data)
        products_df = spark.createDataFrame(products_data)
        orders_df = spark.createDataFrame(orders_data)
        order_items_df = spark.createDataFrame(order_items_data)

        # ✅ Coalesce and write to single file for each DataFrame, then rename
        def save_dataframe(df, name):
            temp_path = os.path.join(timestamped_folder, f"raw_{name}_temp_{file_timestamp}")
            final_path = os.path.join(timestamped_folder, f"raw_{name}_{file_timestamp}.csv")

            # Merge partitions into one before writing
            df.coalesce(1).write.csv(temp_path, header=True)

            # Move the part file to the final destination
            for filename in os.listdir(temp_path):
                if filename.startswith("part-"):
                    shutil.move(os.path.join(temp_path, filename), final_path)
                    break

            # Clean up the temp directory
            shutil.rmtree(temp_path)

        # Save DataFrames using the save function
        save_dataframe(customers_df, "customers")
        save_dataframe(products_df, "products")
        save_dataframe(orders_df, "orders")
        save_dataframe(order_items_df, "order_items")

        logging.info(f"✅ Files successfully saved in {timestamped_folder}")

    except Exception as e:
        logging.error(f"❌ Error during data generation: {e}")

if __name__ == "__main__":
    main()
