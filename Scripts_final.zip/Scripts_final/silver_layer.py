import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
import datetime
import logging
import shutil
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType
import configparser
from datetime import datetime

'''
# Configuration
bronze_folder = "/home/bsk/PycharmProjects/DE/medallion/bronze"
silver_folder = "/home/bsk/PycharmProjects/DE/medallion/silver"
os.makedirs(silver_folder, exist_ok=True)
'''

def read_config():
    """Load config.ini from the project root directory."""
    script_dir = os.path.dirname(os.path.abspath(__file__))  # Get script directory
    config_path = os.path.join(script_dir, "config2.ini")
    # project_root = os.path.abspath(os.path.join(script_dir, ".."))  # Move up one level
    # config_path = os.path.join(project_root, "config2.ini")  # Full path to config.ini

    if not os.path.exists(config_path):  # Check if file exists
        raise FileNotFoundError(f"Error: config.ini not found at {config_path}")

    config_obj = configparser.ConfigParser()
    config_obj.read(config_path)  # Read config file

    if not config_obj.sections():  # Ensure config isn't empty
        raise ValueError("Error: config.ini is empty or misformatted!")

    return config_obj

# Load config.ini
config = read_config()

# Retrieve paths
silver_input = config['PATHS']['input_path_silver_processing_layer']
silver_output = config['PATHS']['output_path_silver_processing_layer']


# Print results
print(f"Silver Input: {silver_input}")
print(f"Silver Output: {silver_output}")


log_file = config['PATHS']['logs_folder']
logging.basicConfig(filename=log_file, level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


# Initialize Spark session
spark = SparkSession.builder.appName("SilverLayerProcessing").getOrCreate()

def get_latest_folder(path):
    """Finds the most recent timestamped folder."""
    folders = [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
    timestamped_folders = sorted([d for d in folders if d.startswith("bronze_files_")], reverse=True)
    return os.path.join(path, timestamped_folders[0]) if timestamped_folders else None

def process_silver_layer():
    """Processes raw CSVs into Silver layer with cleaning and referential integrity enforcement."""
    latest_bronze_folder = get_latest_folder(silver_input)
    if not latest_bronze_folder:
        logging.error("No bronze data found!")
        return

    # Extract the correct timestamp from the latest bronze folder
    bronze_timestamp = '_'.join(os.path.basename(latest_bronze_folder).split('_')[-2:])

    # Generate new timestamp for silver processing
    silver_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Initialize the paths for silver and quarantine folders
    silver_timestamped_folder = os.path.join(silver_output, f"silver_files_{silver_timestamp}")
    quarantine_folder = os.path.join(silver_timestamped_folder, f"quarantine_{silver_timestamp}")

    # Define files and columns
    files = {
        "customers": ["customer_id", "full_name", "email", "address", "city", "state", "ingest_timestamp", "source_system"],
        "products": ["product_id", "product_name", "category", "price", "ingest_timestamp", "source_system"],
        "orders": ["order_id", "order_date", "customer_id", "total_amount", "order_status", "ingest_timestamp", "source_system"],
        "order_items": ["order_item_id", "order_id", "product_id", "quantity", "unit_price", "ingest_timestamp", "source_system"],
    }

    # Load data from bronze files
    bronze_data = {}
    for file in files.keys():
        bronze_file_path = os.path.join(latest_bronze_folder, f"bronze_{file}_{bronze_timestamp}.csv")
        if os.path.exists(bronze_file_path):
            df = spark.read.csv(bronze_file_path, header=True, inferSchema=True)
            bronze_data[file] = df
        else:
            logging.warning(f"Bronze file not found: {bronze_file_path}")
            bronze_data[file] = spark.createDataFrame([], files[file])  # Empty dataframe to prevent errors

    # Define the schema explicitly for the "orders" DataFrame
    orders_schema = StructType([
        StructField("order_id", IntegerType(), True),
        StructField("order_date", StringType(), True),
        StructField("customer_id", IntegerType(), True),
        StructField("total_amount", FloatType(), True),
        StructField("order_status", StringType(), True),
        StructField("ingest_timestamp", StringType(), True),
        StructField("source_system", StringType(), True),
        StructField("order_item_id", IntegerType(), True),
        StructField("product_id", IntegerType(), True),
        StructField("quantity", IntegerType(), True),
        StructField("unit_price", FloatType(), True),
        StructField("product_name", StringType(), True),
        StructField("category", StringType(), True),
        StructField("order_id", IntegerType(), True),
        StructField("price", FloatType(), True),
    ])

    # Initialize quarantined DataFrames
    quarantined_orders = spark.createDataFrame([], orders_schema)
    quarantined_order_items = spark.createDataFrame([], orders_schema)

    # Referential Integrity Checks
    if bronze_data["customers"].count() > 0 and bronze_data["orders"].count() > 0:
        valid_orders = bronze_data["orders"].join(bronze_data["customers"], "customer_id", "inner")
        logging.info(f"Valid orders count after join: {valid_orders.count()}")

        # Debug unmatched orders
        unmatched_orders = bronze_data["orders"].join(bronze_data["customers"], "customer_id", "left_anti")
        logging.info(f"Unmatched orders count: {unmatched_orders.count()}")
        if unmatched_orders.count() > 0:
            unmatched_orders.show(10)  # Show first 10 unmatched records for further inspection

        # Process valid orders
        valid_orders = valid_orders.drop(bronze_data["customers"].ingest_timestamp)
        valid_orders = valid_orders.drop(bronze_data["customers"].source_system)
        valid_orders = valid_orders.withColumn("ingest_timestamp", lit(silver_timestamp))
        valid_orders = valid_orders.select(*bronze_data["orders"].columns)

        quarantined_orders = bronze_data["orders"].join(valid_orders, "order_id", "left_anti")
        bronze_data["orders"] = valid_orders

    if bronze_data["orders"].count() > 0 and bronze_data["order_items"].count() > 0:
        valid_order_items = bronze_data["order_items"].join(bronze_data["orders"], "order_id", "inner")
        logging.info(f"Valid order items count after join: {valid_order_items.count()}")

        # Debug unmatched order items
        unmatched_order_items = bronze_data["order_items"].join(bronze_data["orders"], "order_id", "left_anti")
        logging.info(f"Unmatched order items count: {unmatched_order_items.count()}")
        if unmatched_order_items.count() > 0:
            unmatched_order_items.show(10)  # Show first 10 unmatched records for further inspection

        # Process valid order items
        valid_order_items = valid_order_items.drop(bronze_data["orders"].ingest_timestamp)
        valid_order_items = valid_order_items.drop(bronze_data["orders"].source_system)
        valid_order_items = valid_order_items.withColumn("ingest_timestamp", lit(silver_timestamp))
        valid_order_items = valid_order_items.select(*bronze_data["order_items"].columns)

        quarantined_order_items = bronze_data["order_items"].join(valid_order_items, "order_item_id", "left_anti")
        bronze_data["order_items"] = valid_order_items

    if bronze_data["products"].count() > 0 and bronze_data["order_items"].count() > 0:
        if bronze_data["products"].count() > 0:
            valid_products = bronze_data["order_items"].join(bronze_data["products"], "product_id", "inner")
        else:
            valid_products = bronze_data["order_items"]  # Keep all order items if no products are found.

        logging.info(f"Valid products count after product join: {valid_products.count()}")

        # Debug unmatched products
        unmatched_products = bronze_data["order_items"].join(bronze_data["products"], "product_id", "left_anti")
        logging.info(f"Unmatched products count: {unmatched_products.count()}")
        if unmatched_products.count() > 0:
            unmatched_products.show(10)  # Show first 10 unmatched records for further inspection

        # Process valid products
        valid_products = valid_products.drop(bronze_data["products"].ingest_timestamp)
        valid_products = valid_products.drop(bronze_data["products"].source_system)
        valid_products = valid_products.withColumn("ingest_timestamp", lit(silver_timestamp))
        valid_products = valid_products.select(*bronze_data["order_items"].columns)

        if valid_products.count() > 0 and bronze_data["order_items"].count() > 0:
            quarantined_order_items = quarantined_order_items.union(valid_products.subtract(
                bronze_data["order_items"])) if quarantined_order_items.count() > 0 else valid_products.subtract(
                bronze_data["order_items"])

        if valid_products.count() > 0:
            bronze_data["order_items"] = valid_products

    logging.info(f"Final Valid Orders Count: {bronze_data['orders'].count()}")
    logging.info(f"Final Valid Order Items Count: {bronze_data['order_items'].count()}")
    logging.info(f"Final Quarantined Orders Count: {quarantined_orders.count()}")
    logging.info(f"Final Quarantined Order Items Count: {quarantined_order_items.count()}")

    # Only create silver folders and write data if there is valid data
    if any([df.count() > 0 for df in bronze_data.values()]):
        os.makedirs(silver_timestamped_folder, exist_ok=True)

        # Save valid data to silver
        for file, df in bronze_data.items():
            if df.count() > 0:
                silver_temp_path = os.path.join(silver_timestamped_folder, f"silver_{file}_temp_{silver_timestamp}")
                final_silver_path = os.path.join(silver_timestamped_folder, f"silver_{file}_{silver_timestamp}.csv")

                # Coalesce and write to a single file
                df.coalesce(1).write.csv(silver_temp_path, header=True, mode="overwrite")

                # Move the part file to the final destination
                for filename in os.listdir(silver_temp_path):
                    if filename.startswith("part-"):
                        shutil.move(os.path.join(silver_temp_path, filename), final_silver_path)
                        break

                # Clean up the temp directory
                shutil.rmtree(silver_temp_path)

                logging.info(f"Saved silver file: {final_silver_path}")

            # Only create quarantine folder and save quarantined data if any exists
            if quarantined_orders.count() > 0 or quarantined_order_items.count() > 0:
                os.makedirs(quarantine_folder, exist_ok=True)

                if quarantined_orders.count() > 0:
                    quarantine_orders_temp_path = os.path.join(quarantine_folder,
                                                               f"quarantine_orders_temp_{silver_timestamp}")
                    final_quarantine_orders_path = os.path.join(quarantine_folder,
                                                                f"quarantine_orders_{silver_timestamp}.csv")

                    quarantined_orders.coalesce(1).write.csv(quarantine_orders_temp_path, header=True, mode="overwrite")

                    for filename in os.listdir(quarantine_orders_temp_path):
                        if filename.startswith("part-"):
                            shutil.move(os.path.join(quarantine_orders_temp_path, filename),
                                        final_quarantine_orders_path)
                            break

                    shutil.rmtree(quarantine_orders_temp_path)
                    logging.warning(f"Quarantined {quarantined_orders.count()} orders due to missing customer_id.")

                if quarantined_order_items.count() > 0:
                    quarantine_order_items_temp_path = os.path.join(quarantine_folder,
                                                                    f"quarantine_order_items_temp_{silver_timestamp}")
                    final_quarantine_order_items_path = os.path.join(quarantine_folder,
                                                                     f"quarantine_order_items_{silver_timestamp}.csv")

                    quarantined_order_items.coalesce(1).write.csv(quarantine_order_items_temp_path, header=True,
                                                                  mode="overwrite")

                    for filename in os.listdir(quarantine_order_items_temp_path):
                        if filename.startswith("part-"):
                            shutil.move(os.path.join(quarantine_order_items_temp_path, filename),
                                        final_quarantine_order_items_path)
                            break

                    shutil.rmtree(quarantine_order_items_temp_path)
                    logging.warning(
                        f"Quarantined {quarantined_order_items.count()} order_items due to missing orders or products.")

                logging.info(f"Quarantine files stored in: {quarantine_folder}")

    logging.info(f"Silver files stored in: {silver_timestamped_folder}")

if __name__ == "__main__":
    process_silver_layer()
