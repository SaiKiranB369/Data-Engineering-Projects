import os
import pandas as pd
import json
import datetime
import logging

# Configuration
config_file = "C:/Users/Lenovo/PycharmProjects/DE/config.json"


def load_config(config_file=config_file):
    with open(config_file, 'r') as f:
        return json.load(f)


config = load_config()
output_folder = config["paths"]["output_folder"]
bronze_folder = os.path.join("C:/Users/Lenovo/PycharmProjects/DE/medallion/bronze")
os.makedirs(bronze_folder, exist_ok=True)

# Logging setup
log_file = "C:/Users/Lenovo/PycharmProjects/DE/logs/pipeline_log.txt"
logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


def get_latest_folder(path_pattern):
    """Finds the most recent timestamped folder matching the pattern."""
    folders = [d for d in os.listdir(path_pattern) if os.path.isdir(os.path.join(path_pattern, d))]
    timestamped_folders = sorted([d for d in folders if d.startswith("raw_files_")], reverse=True)
    return os.path.join(path_pattern, timestamped_folders[0]) if timestamped_folders else None


def validate_schema(df, expected_columns):
    """Validates if DataFrame has the expected schema."""
    #return set(df.columns) == set(expected_columns)
    if set(df.columns) != set(expected_columns):
        logging.error(f"Schema mismatch: {set(df.columns)} != {set(expected_columns)}")
        return False
    return True


def process_bronze_layer(raw_path, bronze_folder):
    """Processes raw CSVs into Bronze layer with basic validation."""
    latest_raw_folder = get_latest_folder(raw_path)
    if not latest_raw_folder:
        logging.error("No raw data found!")
        return

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    bronze_timestamped_folder = os.path.join(bronze_folder, f"bronze_files_{timestamp}")
    os.makedirs(bronze_timestamped_folder, exist_ok=True)

    files = {
        "customers": ["customer_id", "full_name", "email", "address", "city", "state"],
        "products": ["product_id", "product_name", "category", "price"],
        "orders": ["order_id", "order_date", "customer_id", "total_amount", "order_status"],
        "order_items": ["order_item_id", "order_id", "product_id", "quantity", "unit_price"]
    }

    source_system = "DataIngestionSystem"
    ingest_timestamp = datetime.datetime.now().isoformat()
    raw_timestamp = '_'.join(os.path.basename(latest_raw_folder).split('_')[-2:])

    for file, columns in files.items():
        raw_file_path = os.path.join(latest_raw_folder, f"raw_{file}_{raw_timestamp}.csv")
        if os.path.exists(raw_file_path):
            df = pd.read_csv(raw_file_path)
            if validate_schema(df, columns):
                df["ingest_timestamp"] = ingest_timestamp
                df["source_system"] = source_system
                bronze_file_path = os.path.join(bronze_timestamped_folder, f"bronze_{file}_{timestamp}.csv")
                df.to_csv(bronze_file_path, index=False)
                logging.info(f"Saved bronze file: {bronze_file_path}")
            else:
                logging.error(f"Schema mismatch in {file}")
        else:
            logging.warning(f"Raw file not found: {raw_file_path}")

    logging.info(f"Bronze files saved in {bronze_timestamped_folder}")


if __name__ == "__main__":
    raw_path = "C:/Users/Lenovo/PycharmProjects/DE/output"
    process_bronze_layer(raw_path, bronze_folder)