import os
import datetime
import pandas as pd
import logging

# Paths for Silver and Gold folders
silver_folder = "C:/Users/Lenovo/PycharmProjects/DE/medallion/silver"
gold_folder = "C:/Users/Lenovo/PycharmProjects/DE/medallion/gold"
os.makedirs(gold_folder, exist_ok=True)

# Logging setup
logging.basicConfig(
    filename="C:/Users/Lenovo/PycharmProjects/DE/logs/pipeline_log.txt",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)


def get_latest_folder(path, prefix="silver_files_"):
    """Find the most recent timestamped Silver folder."""
    folders = [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
    timestamped_folders = sorted([d for d in folders if d.startswith(prefix)], reverse=True)
    return os.path.join(path, timestamped_folders[0]) if timestamped_folders else None


def load_silver_data(latest_silver_folder):
    """Load Silver layer data and handle missing files gracefully."""
    files = {
        "customers": ["customer_id", "full_name", "email", "address", "city", "state"],
        "products": ["product_id", "product_name", "category", "price"],
        "orders": ["order_id", "order_date", "customer_id", "total_amount", "order_status"],
        "order_items": ["order_item_id", "order_id", "product_id", "quantity", "unit_price"],
    }

    data = {}
    silver_timestamp = '_'.join(os.path.basename(latest_silver_folder).split('_')[-2:])

    for file, columns in files.items():
        file_path = os.path.join(latest_silver_folder, f"silver_{file}_{silver_timestamp}.csv")
        if os.path.exists(file_path):
            data[file] = pd.read_csv(file_path)
            logging.info(f"Loaded {file} from {file_path}")
        else:
            logging.warning(f"Missing Silver file: {file_path} (likely quarantined)")
            data[file] = None  # Handle missing files gracefully

    return data


def process_gold_layer():
    """Process Gold layer by joining data and applying business rules."""
    latest_silver_folder = get_latest_folder(silver_folder)
    if not latest_silver_folder:
        logging.error("No Silver data found!")
        return

    # Generate a timestamp for Gold layer storage
    gold_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    gold_timestamped_folder = os.path.join(gold_folder, f"gold_files_{gold_timestamp}")
    os.makedirs(gold_timestamped_folder, exist_ok=True)

    #silver_timestamp = '_'.join(os.path.basename(latest_silver_folder).split('_')[-2:])

    # Load Silver data
    data = load_silver_data(latest_silver_folder)

    # Check for necessary tables before processing
    if (data["orders"] is None or data["orders"].empty) or \
       (data["products"] is None or data["products"].empty) or \
       (data["customers"] is None or data["customers"].empty):
        logging.error("Essential Silver tables missing or empty. Skipping Gold processing.")
        return

    # **Business Rule 1: Exclude CANCELLED orders**
    orders_filtered = data["orders"][data["orders"]["order_status"] != "CANCELLED"]

    # **Business Rule 2: Date Validation**
    # Assuming business rules allow order dates from 2020 onward
    orders_validated = orders_filtered[orders_filtered["order_date"] >= "2020-01-01"]

    # Handle missing `order_items`
    if data["order_items"] is not None and not data["order_items"].empty:
        # **Business Rule 3: Create fact_sales table with product details**
        merged = orders_validated.merge(data["order_items"], on="order_id", how="inner")
        merged = merged.merge(data["products"], on="product_id", how="inner")
        merged["computed_total"] = merged["quantity"] * merged["unit_price"]

        # **Sum Check Validation**
        mismatch = merged[merged["total_amount"] != merged["computed_total"]]

        # Create folder for fact_sales only if the file is generated
        fact_sales_folder = os.path.join(gold_timestamped_folder, f"fact_sales_{gold_timestamp}")
        os.makedirs(fact_sales_folder, exist_ok=True)

        # Save fact_sales to its respective folder inside Gold layer
        gold_file_path = os.path.join(fact_sales_folder, f"fact_sales_{gold_timestamp}.csv")
        merged.to_csv(gold_file_path, index=False)
        logging.info(f"Saved fact_sales table with product details to: {gold_file_path}")

        # Log sum check mismatches
        if not mismatch.empty:
            logging.warning(f"Sum Check Failed for {len(mismatch)} orders.")
    else:
        # **Business Rule 3: Create fact_sales table without product details**
        orders_validated["computed_total"] = orders_validated["total_amount"]

        # **Sum Check Validation for simplified data**
        mismatch = orders_validated[orders_validated["total_amount"] != orders_validated["computed_total"]]

        # Create folder for fact_sales_simplified only if the file is generated
        fact_sales_simplified_folder = os.path.join(gold_timestamped_folder, f"fact_sales_simplified_{gold_timestamp}")
        os.makedirs(fact_sales_simplified_folder, exist_ok=True)

        # Save fact_sales_simplified to its respective folder inside Gold layer
        gold_file_path = os.path.join(fact_sales_simplified_folder, f"fact_sales_simplified_{gold_timestamp}.csv")
        orders_validated.to_csv(gold_file_path, index=False)
        logging.info(f"Saved simplified fact_sales table to: {gold_file_path}")

        # Log sum check mismatches
        if not mismatch.empty:
            logging.warning(f"Sum Check Failed for {len(mismatch)} orders in simplified version.")

    logging.info(f"Gold files stored in: {gold_timestamped_folder}")


if __name__ == "__main__":
    process_gold_layer()
