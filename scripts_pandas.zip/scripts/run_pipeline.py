import subprocess
import logging

logging.basicConfig(filename="pipeline.log", level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

scripts = [
    "generate_data_with_config.py",
    "bronze_layer.py",
    "silver_layer.py",
    "gold_layer.py"
]

for script in scripts:
    try:
        logging.info(f"Starting {script}...")
        result = subprocess.run(["python", script], capture_output=True, text=True, check=True)
        logging.info(result.stdout)
    except subprocess.CalledProcessError as e:
        logging.error(f"Error in {script}: {e.stderr}")
        logging.error("No new raw data generated. Existing raw data has been processed already.")
        break

logging.info("Pipeline execution finished.")
