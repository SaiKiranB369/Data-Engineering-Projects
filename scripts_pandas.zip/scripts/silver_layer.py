import os
import pandas as pd
import datetime
import logging

# Configuration
bronze_folder = "C:/Users/Lenovo/PycharmProjects/DE/medallion/bronze"
silver_folder = "C:/Users/Lenovo/PycharmProjects/DE/medallion/silver"
os.makedirs(silver_folder, exist_ok=True)

# Logging setup
logging.basicConfig(
    filename="C:/Users/Lenovo/PycharmProjects/DE/logs/pipeline_log.txt",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

def get_latest_folder(path):
    """Finds the most recent timestamped folder."""
    folders = [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
    timestamped_folders = sorted([d for d in folders if d.startswith("bronze_files_")], reverse=True)
    return os.path.join(path, timestamped_folders[0]) if timestamped_folders else None

def process_silver_layer():
    """Processes raw CSVs into Silver layer with cleaning and referential integrity enforcement."""
    latest_bronze_folder = get_latest_folder(bronze_folder)
    if not latest_bronze_folder:
        logging.error("No bronze data found!")
        return

    # Extract the correct timestamp from the latest bronze folder
    bronze_timestamp = '_'.join(os.path.basename(latest_bronze_folder).split('_')[-2:])

    # Generate new timestamp for silver processing
    silver_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    silver_timestamped_folder = os.path.join(silver_folder, f"silver_files_{silver_timestamp}")
    quarantine_folder = os.path.join(silver_timestamped_folder, f"quarantine_{silver_timestamp}")
    os.makedirs(silver_timestamped_folder, exist_ok=True)
    os.makedirs(quarantine_folder, exist_ok=True)

    # Define files and columns
    files = {
        "customers": ["customer_id", "full_name", "email", "address", "city", "state"],
        "products": ["product_id", "product_name", "category", "price"],
        "orders": ["order_id", "order_date", "customer_id", "total_amount", "order_status"],
        "order_items": ["order_item_id", "order_id", "product_id", "quantity", "unit_price"],
    }

    # Load data from bronze files
    data = {}
    for file in files.keys():
        bronze_file_path = os.path.join(latest_bronze_folder, f"bronze_{file}_{bronze_timestamp}.csv")
        if os.path.exists(bronze_file_path):
            df = pd.read_csv(bronze_file_path)
            data[file] = df
        else:
            logging.warning(f"Bronze file not found: {bronze_file_path}")
            data[file] = pd.DataFrame(columns=files[file])  # Empty dataframe to prevent errors

    # Initialize quarantine DataFrames
    quarantined_orders = pd.DataFrame(columns=files["orders"])
    quarantined_order_items = pd.DataFrame(columns=files["order_items"])

    # Referential Integrity Checks
    if not data["customers"].empty and not data["orders"].empty:
        valid_orders = data["orders"]["customer_id"].isin(data["customers"]["customer_id"])
        quarantined_orders = data["orders"][~valid_orders]
        data["orders"] = data["orders"][valid_orders]

    if not data["orders"].empty and not data["order_items"].empty:
        valid_order_items = data["order_items"]["order_id"].isin(data["orders"]["order_id"])
        quarantined_order_items = data["order_items"][~valid_order_items]
        data["order_items"] = data["order_items"][valid_order_items]

    if not data["products"].empty and not data["order_items"].empty:
        valid_products = data["order_items"]["product_id"].isin(data["products"]["product_id"])
        quarantined_order_items = pd.concat([quarantined_order_items, data["order_items"][~valid_products]], ignore_index=True)
        data["order_items"] = data["order_items"][valid_products]

    # Save valid data to silver
    for file, df in data.items():
        silver_file_path = os.path.join(silver_timestamped_folder, f"silver_{file}_{silver_timestamp}.csv")
        if not df.empty:
            df.to_csv(silver_file_path, index=False)
            logging.info(f"Saved silver file: {silver_file_path}")

    # Save quarantined data
    if not quarantined_orders.empty:
        quarantine_orders_path = os.path.join(quarantine_folder, f"quarantine_orders_{silver_timestamp}.csv")
        quarantined_orders.to_csv(quarantine_orders_path, index=False)
        logging.warning(f"Quarantined {len(quarantined_orders)} orders due to missing customer_id.")

    if not quarantined_order_items.empty:
        quarantine_order_items_path = os.path.join(quarantine_folder, f"quarantine_order_items_{silver_timestamp}.csv")
        quarantined_order_items.to_csv(quarantine_order_items_path, index=False)
        logging.warning(f"Quarantined {len(quarantined_order_items)} order_items due to missing orders or products.")

    logging.info(f"Silver files stored in: {silver_timestamped_folder}")
    logging.info(f"Quarantine files stored in: {quarantine_folder}")

if __name__ == "__main__":
    process_silver_layer()
