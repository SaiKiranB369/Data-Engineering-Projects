import os
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import logging
from pyspark.sql.functions import lit
import shutil

# Initialize Spark session
spark = SparkSession.builder \
    .appName("GoldLayerProcessing") \
    .getOrCreate()

# Paths for Silver and Gold folders
silver_folder = "/home/bsk/PycharmProjects/DE/medallion/silver"
gold_folder = "/home/bsk/PycharmProjects/DE/medallion/gold"
os.makedirs(gold_folder, exist_ok=True)

# Logging setup
logging.basicConfig(
    filename="/home/bsk/PycharmProjects/DE/logs/pipeline_log.txt",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)


def get_latest_folder(path, prefix="silver_files_"):
    """Find the most recent timestamped Silver folder."""
    folders = [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
    timestamped_folders = sorted([d for d in folders if d.startswith(prefix)], reverse=True)
    return os.path.join(path, timestamped_folders[0]) if timestamped_folders else None


def load_silver_data(latest_silver_folder):
    """Load Silver layer data and handle missing files gracefully."""
    files = {
        "customers": ["customer_id", "full_name", "email", "address", "city", "state"],
        "products": ["product_id", "product_name", "category", "price"],
        "orders": ["order_id", "order_date", "customer_id", "total_amount", "order_status"],
        "order_items": ["order_item_id", "order_id", "product_id", "quantity", "unit_price"],
    }

    data = {}
    silver_timestamp = '_'.join(os.path.basename(latest_silver_folder).split('_')[-2:])

    for file, columns in files.items():
        file_path = os.path.join(latest_silver_folder, f"silver_{file}_{silver_timestamp}.csv")
        if os.path.exists(file_path):
            data[file] = spark.read.csv(file_path, header=True, inferSchema=True)
            logging.info(f"Loaded {file} from {file_path}")
        else:
            logging.warning(f"Missing Silver file: {file_path} (likely quarantined)")
            data[file] = None  # Handle missing files gracefully

    return data


def save_dataframe(df, name, timestamp, timestamped_folder):
    temp_path = os.path.join(timestamped_folder, f"{name}_temp_{timestamp}")
    final_path = os.path.join(timestamped_folder, f"{name}_{timestamp}.csv")

    # Write to a temporary folder
    df.coalesce(1).write.csv(temp_path, header=True, mode="overwrite")

    # Move the CSV file from temp folder to final destination
    for filename in os.listdir(temp_path):
        if filename.startswith("part-"):
            shutil.move(os.path.join(temp_path, filename), final_path)
            break

    # Remove the temporary folder
    shutil.rmtree(temp_path)

def process_gold_layer():
    """Process Gold layer by joining data and applying business rules."""
    latest_silver_folder = get_latest_folder(silver_folder)
    if not latest_silver_folder:
        logging.error("No Silver data found!")
        return

    # Generate a timestamp for Gold layer storage
    gold_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    gold_timestamped_folder = os.path.join(gold_folder, f"gold_files_{gold_timestamp}")
    os.makedirs(gold_timestamped_folder, exist_ok=True)

    # Load Silver data
    data = load_silver_data(latest_silver_folder)

    # Check for necessary tables before processing
    if (data["orders"] is None or data["orders"].rdd.isEmpty()) or \
            (data["products"] is None or data["products"].rdd.isEmpty()) or \
            (data["customers"] is None or data["customers"].rdd.isEmpty()):
        logging.error("Essential Silver tables missing or empty. Skipping Gold processing.")
        return

    # Check loaded data
    logging.info(f"Orders loaded: {data['orders'].count()} rows")
    logging.info(f"Products loaded: {data['products'].count()} rows")
    logging.info(f"Order items loaded: {data['order_items'].count()} rows")

    # **Business Rule 1: Exclude CANCELLED orders**
    orders_filtered = data["orders"].filter(col("order_status") != "CANCELLED")
    logging.info(f"Orders after filtering CANCELLED status: {orders_filtered.count()} rows")

    # **Business Rule 2: Date Validation**
    orders_validated = orders_filtered.filter(col("order_date") >= "2020-01-01")
    logging.info(f"Orders after validating date: {orders_validated.count()} rows")

    # **Business Rule 3: Create fact_sales table with product details (if order_items exists)**
    if data["order_items"] is not None and not data["order_items"].rdd.isEmpty():
        merged = orders_validated.join(data["order_items"], on="order_id", how="left_outer") \
            .join(data["products"], on="product_id", how="left_outer")
        logging.info(f"Merged data (with product details): {merged.count()} rows")

        # Add computed total (only if not already present)
        merged = merged.withColumn("computed_total", col("quantity") * col("unit_price"))

        # Drop 'ingest_timestamp' and 'source_system' if they already exist
        if "ingest_timestamp" in merged.columns:
            merged = merged.drop("ingest_timestamp")
        if "source_system" in merged.columns:
            merged = merged.drop("source_system")

        # Add ingestion timestamp and source system column
        merged = merged.withColumn("ingest_timestamp", lit(gold_timestamp)) \
            .withColumn("source_system", lit("Redshift"))

        # **Sum Check Validation**
        mismatch = merged.filter(col("total_amount") != col("computed_total"))
        logging.info(f"Sum Check Mismatch: {mismatch.count()} rows")

        # Split data based on nulls in critical fields
        fact_sales_data = merged.filter(
            col("order_id").isNotNull() &
            col("product_id").isNotNull() &
            col("quantity").isNotNull() &
            col("unit_price").isNotNull() &
            col("total_amount").isNotNull()
        )

        fact_sales_simplified_data = merged.filter(
            col("order_id").isNull() |
            col("product_id").isNull() |
            col("quantity").isNull() |
            col("unit_price").isNull() |
            col("total_amount").isNull()
        )

        # Save fact_sales data (no nulls)
        if fact_sales_data.count() > 0:
            fact_sales_timestamp_folder = os.path.join(gold_timestamped_folder, f"fact_sales_{gold_timestamp}")
            os.makedirs(fact_sales_timestamp_folder, exist_ok=True)

            # Save fact_sales to its respective folder inside Gold layer
            save_dataframe(fact_sales_data, "fact_sales", gold_timestamp, fact_sales_timestamp_folder)

            logging.info(f"Saved fact_sales table with product details to: {fact_sales_timestamp_folder}")

        # Save fact_sales_simplified data (with nulls)
        if fact_sales_simplified_data.count() > 0:
            fact_sales_simplified_timestamp_folder = os.path.join(gold_timestamped_folder,
                                                                  f"fact_sales_simplified_{gold_timestamp}")
            os.makedirs(fact_sales_simplified_timestamp_folder, exist_ok=True)

            # Save fact_sales_simplified to its respective folder inside Gold layer
            save_dataframe(fact_sales_simplified_data, "fact_sales_simplified", gold_timestamp, fact_sales_simplified_timestamp_folder)

            logging.info(f"Saved simplified fact_sales table to: {fact_sales_simplified_timestamp_folder}")

        # Log sum check mismatches
        if not mismatch.rdd.isEmpty():
            logging.warning(f"Sum Check Failed for {mismatch.count()} orders.")
    else:
        # **Business Rule 3: Create fact_sales simplified version (without product details)**
        logging.info("Processing simplified version of fact_sales (without product details)...")

        # Use orders_validated directly as there are no order_items
        orders_validated = orders_validated.withColumn("computed_total", col("total_amount"))

        # Drop 'ingest_timestamp' and 'source_system' if they already exist
        if "ingest_timestamp" in orders_validated.columns:
            orders_validated = orders_validated.drop("ingest_timestamp")
        if "source_system" in orders_validated.columns:
            orders_validated = orders_validated.drop("source_system")

        # Add ingestion timestamp and source system column
        orders_validated = orders_validated.withColumn("ingest_timestamp", lit(gold_timestamp)) \
            .withColumn("source_system", lit("Redshift"))

        # Split simplified data based on nulls
        fact_sales_simplified_data = orders_validated.filter(
            col("order_id").isNull() |
            col("product_id").isNull() |
            col("quantity").isNull() |
            col("unit_price").isNull() |
            col("total_amount").isNull()
        )

        fact_sales_valid_data = orders_validated.filter(
            col("order_id").isNotNull() &
            col("product_id").isNotNull() &
            col("quantity").isNotNull() &
            col("unit_price").isNotNull() &
            col("total_amount").isNotNull()
        )

        # Save valid fact_sales data (no nulls)
        if fact_sales_valid_data.count() > 0:
            fact_sales_simplified_timestamp_folder = os.path.join(gold_timestamped_folder,
                                                                  f"fact_sales_simplified_{gold_timestamp}")
            os.makedirs(fact_sales_simplified_timestamp_folder, exist_ok=True)

            # Save fact_sales_simplified to its respective folder inside Gold layer
            save_dataframe(fact_sales_valid_data, "fact_sales_simplified", gold_timestamp, fact_sales_simplified_timestamp_folder)

            logging.info(f"Saved valid fact_sales table to: {fact_sales_simplified_timestamp_folder}")

        # Log sum check mismatches
        if fact_sales_simplified_data.count() > 0:
            logging.warning(f"Sum Check Failed for simplified fact_sales (due to null values in required fields).")

    logging.info(f"Gold files stored in: {gold_timestamped_folder}")



if __name__ == "__main__":
    process_gold_layer()
