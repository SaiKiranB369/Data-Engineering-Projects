#!/bin/bash

# Run the first script
python3 /home/bsk/PycharmProjects/DE/scripts/generate_data_with_config.py
if [ $? -ne 0 ]; then
  echo "generate_data_with_config.py failed. Exiting."
  exit 1
fi

# Run the second script
python3 /home/bsk/PycharmProjects/DE/scripts/bronze_layer.py
if [ $? -ne 0 ]; then
  echo "bronze_layer.py failed. Exiting."
  exit 1
fi

# Run the third script
python3 /home/bsk/PycharmProjects/DE/scripts/silver_layer.py
if [ $? -ne 0 ]; then
  echo "silver_layer.py failed. Exiting."
  exit 1
fi

# Run the fourth script
python3 /home/bsk/PycharmProjects/DE/scripts/gold_layer.py
if [ $? -ne 0 ]; then
  echo "gold_layer.py failed. Exiting."
  exit 1
fi

echo "All scripts executed successfully."
